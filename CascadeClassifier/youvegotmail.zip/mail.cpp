#include <string>
#include <iostream>
#include <cstdlib>

int main () {

    system("/home/pi/EECS400/cascadeClassifier/mail.sh");
}
