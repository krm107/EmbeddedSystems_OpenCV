#!/bin/sh
python mail.py 
